			<div class="container-fluid" style="background-color:#f8f7f2;">
				<div class="row">
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-md-8 text-center animation-element fade-up">
								<h2 class="underline-gold gray mt-5">Our facilities</h2>
								<p class="pb-5 gold">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus
faucibus velit ac lorem sollicitudin rutrum. Suspendisse bibendum.
Donsectetur. Consectetur adipiscing elit. Vivamus faucibus velit.</p>					
							</div>
							<div class="mb-5 p-4" style="background-color: #ffffff;">
								<img src="<?php bloginfo('stylesheet_directory'); ?>/images/ourfacilities.jpg">
							</div>
						</div>
					</div>
				</div>
			</div>
