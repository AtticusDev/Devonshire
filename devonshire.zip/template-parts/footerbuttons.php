			<div class="container-fluid footerButtons" style="background: linear-gradient(to right, #cca969 50%, #666666 50%);">
				<div class="row">
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-md-6 text-center text-white pt-5 pb-5" style="background-color: #cca969;">
								<h3 class="underline">About Us</h3>
								<p class="uppercase mb-1">find out about the <br />clinic and how we can help you</p>
								<a href="/contact/" class="btn smallBlueGoldBtn">Read More</a>
							</div>
							<div class="col-md-6 text-center text-white pt-5 pb-5" style="background-color: #666666;">
								<h3 class="underline">Our Consultants</h3>
								<p class="uppercase mb-1">Meet our specialist <br />consultants who are here to help you</p>
								<a href="/contact/" class="btn smallGoldWhiteBtn">Read More</a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
