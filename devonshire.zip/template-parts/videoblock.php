			<div class="container-fluid" style="background-color:#f8f7f2;">
				<div class="row">
					<div class="container">
						<div class="row justify-content-center">
							<div class="col-md-8 text-center animation-element fade-up">
								<h2 class="underline-gold gray mt-5">An introduction<br />to the clinic</h2>
								<p class="pb-5">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus
								faucibus velit ac lorem sollicitudin rutrum. Suspendisse bibendum.</p>					
							</div>
							<div class="mb-5 p-4 animation-element fade-up" style="background-color: #ffffff;">
								<iframe src="https://player.vimeo.com/video/110782325?title=0&byline=0&portrait=0" class="videoBox" frameborder="0" webkitallowfullscreen mozallowfullscreen allowfullscreen></iframe>
							</div>
						</div>
					</div>
				</div>
			</div>
