<a href="<?php the_field('book_appointment', 'option'); ?>" class="btn sideBlueGoldBtn">Book an appointment</a></p>
